import { Component, OnInit } from '@angular/core';
import { ExpenseService } from '../service/expense.service';
import { Router } from '@angular/router';
import { Expense } from '../model/expense';

@Component({
  selector: 'app-add-expense',
  templateUrl: './add-expense.component.html',
  styleUrls: ['./add-expense.component.css']
})
export class AddExpenseComponent implements OnInit {

  exp: any = { expenseCode: 0, expenseType: '', expenseDescription: '' };
  expenses = Expense[]
  // tslint:disable-next-line: no-shadowed-variable
  constructor(private ExpenseService: ExpenseService, private router: Router) { }

  ngOnInit() {

  }
  add() {

    this.ExpenseService.addExpense(this.exp).subscribe(
      data => {
        this.ExpenseService.getData().subscribe( data => {
          this.expenses = data;
        });
      },
      error => console.log(error));
      alert("hello" + this.exp);
      this.ExpenseService.setExpenses(this.exp);

      this.router.navigate(['displayall']);

    }


  }
