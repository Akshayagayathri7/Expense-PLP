import { Component, OnInit, ChangeDetectorRef, Input } from '@angular/core';
import { Expense } from '../model/expense';
import { ExpenseService } from '../service/expense.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ChangeDetectionStrategy } from '@angular/compiler/src/core';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
  //changeDetection: ChangeDetectionStrategy.OnPush
})
export class SearchComponent implements OnInit {

  searchedExpense: Expense;
  searchFound: boolean =  false;
  constructor(private expenseService: ExpenseService, private router: Router, private http: HttpClient) {
  }
  ngOnInit() {
  }

  filterData(value: number) {
    this.expenseService.searchExpense(value);
    this.searchedExpense = this.expenseService.getSearchedExpense();
   // this.cd.detectChanges();
    alert('Data returned');
    if (this.searchedExpense != null) {
      this.searchFound = true;
      alert('Datafound ' + this.searchedExpense.expenseType);
    } else {
      alert('Data not found');
    }
  }
}
