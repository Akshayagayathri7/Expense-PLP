import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Expense } from '../model/expense';
import { throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class ExpenseService {
  expenses: Expense[];
  expenses1: Expense;
  status: string;
  filteredData: Expense[];
  index: number;
  expense: Expense;
  searchedExpense: Expense;
  constructor(private http: HttpClient) {
    this.getExpenses();
    this.http.get<Expense[]>('http://localhost:1111/ExpenseCode/displayall/').subscribe((data: Expense[]) => {
      this.expenses = data;

    });
  }
  getData(): Observable<Expense[]> {
    return this.http.get<Expense[]>('http://localhost:1111/ExpenseCode/displayall/');

  }
  getExpenses() {
    this.getData().subscribe((data: Expense[]) => {
      this.expenses = data;

    });
    return this.expenses;
  }
  handlError(error) {
    console.log(error);
    return throwError;
  }
  getAllExpenses() {
    return this.expenses;
  }
  setExpenses(expen) {
    this.expenses.push(expen);
  }
  getAddExpenses() {
    return this.expenses;
  }
  addExpense(exp: Expense): Expense {
    this.http.post('http://localhost:1111/ExpenseCode/add/', exp).subscribe((data: Expense) => {
      this.expenses1 = data;
    });

    return this.expenses1;
  }

  getSearchedExpense()
  {
    alert('getSearched service ' + this.searchedExpense);
    return this.searchedExpense;
  }
  setSearchedExpense(exp: Expense)
  {
    this.searchedExpense = exp;
    alert('setSearched service ' + this.searchedExpense);
  }
  getSearchedData() {
    return this.filteredData;
  }
  deleteExpense(i: number) {
    return this.http.delete('http://localhost:1111/ExpenseCode/delete/' + i);


  }
  setIndex(i) {
    this.index = i;
  }
  getIndex() {
    return this.index;
  }
  getExpense(i) {
    return this.expenses[i];
  }
  updateExpense(exp: Expense): Expense {

    alert(exp.expenseCode);
    this.http.put('http://localhost:1111/ExpenseCode/update/' + exp.expenseCode, exp).subscribe((data: Expense) => {
      this.expenses1 = data;
    });
    // this.expenses[this.expenses.indexOf(exp)] = this.expenses1;
    return this.expenses1;
  }
 searchExpense(code: number){
     alert('Code value is ' + code);
      this.http.get<Expense>('http://localhost:1111/ExpenseCode/displayExpDet/' + code).subscribe((data: Expense) => {
        this.setSearchedExpense(data);
      this.searchedExpense = data;
      alert('found data is ' + data.expenseCode + ' Expense Description : ' + data.expenseDescription 
      // tslint:disable-next-line: max-line-length
      + ' ' + 'search data is ' + this.searchedExpense.expenseCode + ' searched Expense Description : ' + this.searchedExpense.expenseDescription);
      
    });
    
   }
}
