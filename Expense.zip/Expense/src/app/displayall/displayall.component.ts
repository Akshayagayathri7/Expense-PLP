import { Component, OnInit } from '@angular/core';
import { Expense } from '../model/expense';
import { ExpenseService } from '../service/expense.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-displayall',
  templateUrl: './displayall.component.html',
  styleUrls: ['./displayall.component.css']
})
export class DisplayallComponent implements OnInit {

  expenses: Expense[] = [];
  constructor(private expenseService: ExpenseService, private router: Router) { 
    
  }

  ngOnInit() {
    this.expenses = this.expenseService.getAllExpenses();
    //alert(this.expenses);
  }
  delete(i) {
    this.expenseService.deleteExpense(i).subscribe(
      data => {
        this.expenseService.getData().subscribe( data => {
          this.expenses = data;
        });
      },
      error => console.log(error));
  }
  update(i) {
    this.expenseService.setIndex(i);
    this.router.navigate(['update']);
  }

}
