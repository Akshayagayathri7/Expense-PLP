import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DisplayallComponent } from './displayall/displayall.component';
import { AddExpenseComponent } from './add-expense/add-expense.component';


const routes: Routes = [
  { path: '', redirectTo: 'add', pathMatch: 'full'},
  { path: 'displayall', component: DisplayallComponent},
  { path: 'add', component: AddExpenseComponent}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
