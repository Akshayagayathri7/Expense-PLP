import { Component, OnInit } from '@angular/core';
import { Expense } from '../model/expense';
import { ExpenseService } from '../service/expense.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-displayall',
  templateUrl: './displayall.component.html',
  styleUrls: ['./displayall.component.css']
})
export class DisplayallComponent implements OnInit {

  expenses: Expense[] = [];
  constructor(private expenseService: ExpenseService, private router: Router, private http: HttpClient) {
    this.http.get<Expense[]>('http://localhost:8083/ExpenseCode/displayall/').subscribe((data: Expense[]) => {
      this.expenses = data;
    });
    this.expenses = this.expenseService.getExpenses();

  }

  ngOnInit() {
    this.http.get<Expense[]>('http://localhost:8083/ExpenseCode/displayall/').subscribe((data: Expense[]) => {
      this.expenses = data;
    });
  }

  delete(i) {
    this.expenseService.deleteExpense(i).subscribe(
      data => {
        this.http.get<Expense[]>('http://localhost:8083/ExpenseCode/displayall/').subscribe(data => {
          this.expenses = data;
        });
      },
      error => console.log(error));
  }
  update(i) {
  
    this.expenseService.setIndex(i);
    this.router.navigate(['update']);
  }

}
