import { Component, OnInit, ChangeDetectorRef, Input } from '@angular/core';
import { Expense } from '../model/expense';
import { ExpenseService } from '../service/expense.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ChangeDetectionStrategy } from '@angular/compiler/src/core';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
  //changeDetection: ChangeDetectionStrategy.OnPush
})
export class SearchComponent implements OnInit {

  expensecode: number = 516;
  searchedExpense: Expense;
  searchFound: boolean =  false;
   constructor(private expenseService: ExpenseService, private router: Router, private http: HttpClient) {
  //    this.http.get<Expense>('http://localhost:8083/ExpenseCode/displayExpDet/' + this.expensecode).subscribe((data: Expense) => {
  //   this.searchedExpense = data;
  // });
  }
  ngOnInit() {
    // this.http.get<Expense>('http://localhost:8083/ExpenseCode/displayExpDet/' + this.expensecode).subscribe((data: Expense) => {
    //   this.searchedExpense = data;
    // });
  }
  delay(ms: number) {
    return new Promise( resolve => setTimeout(resolve, ms) );
  }


  filterData(value: number) {


    (async () => { 
      // Do something before delay
      this.expenseService.searchExpense(value);
      //alert('before delay');
      await this.delay(1000);
      this.searchedExpense = this.expenseService.getSearchedExpense();
      //alert('Data returned in search component ' + this.searchedExpense.expenseCode);
     // tslint:disable-next-line: align
     if (this.searchedExpense != null) {
      this.searchFound = true;
      alert('Datafound ' + this.searchedExpense.expenseType);
    } else {
      alert('Data not found');
    }
  })();

  }
}
